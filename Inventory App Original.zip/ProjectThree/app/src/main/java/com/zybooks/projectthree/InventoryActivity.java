package com.zybooks.projectthree;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {

    EditText itemNameInput, itemQtyInput;
    Button addItemButton;
    RecyclerView recyclerView;

    DatabaseHelper db;
    InventoryAdapter adapter;
    ArrayList<InventoryItem> itemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_grid);

        // Bind UI
        itemNameInput = findViewById(R.id.itemNameInput);
        itemQtyInput = findViewById(R.id.itemQtyInput);
        addItemButton = findViewById(R.id.addItemButton);
        recyclerView = findViewById(R.id.recyclerView);

        db = new DatabaseHelper(this);

        // Load items from DB
        itemList = dbHelperToList();

        adapter = new InventoryAdapter(itemList, db, this::refreshList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Add new item
        addItemButton.setOnClickListener(v -> {
            String name = itemNameInput.getText().toString().trim();
            String qtyStr = itemQtyInput.getText().toString().trim();

            if (name.isEmpty() || qtyStr.isEmpty()) {
                Toast.makeText(this, "Please fill out both fields", Toast.LENGTH_SHORT).show();
            } else {
                int quantity = Integer.parseInt(qtyStr);
                db.addInventoryItem(name, quantity);
                itemNameInput.setText("");
                itemQtyInput.setText("");
                refreshList();
                Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private ArrayList<InventoryItem> dbHelperToList() {
        ArrayList<InventoryItem> list = new ArrayList<>();
        var cursor = db.getAllInventoryItems();

        while (cursor.moveToNext()) {
            list.add(new InventoryItem(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getInt(2)
            ));
        }
        cursor.close();
        return list;
    }

    private void refreshList() {
        itemList.clear();
        itemList.addAll(dbHelperToList());
        adapter.notifyDataSetChanged();
    }
}
