package com.zybooks.projectthree;

import android.app.AlertDialog;
import android.content.Context;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    private ArrayList<InventoryItem> items;
    private DatabaseHelper db;
    private Runnable refreshCallback;

    public InventoryAdapter(ArrayList<InventoryItem> items, DatabaseHelper db, Runnable refreshCallback) {
        this.items = items;
        this.db = db;
        this.refreshCallback = refreshCallback;
    }

    @NonNull
    @Override
    public InventoryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryAdapter.ViewHolder holder, int position) {
        InventoryItem item = items.get(position);
        holder.name.setText(item.getName());
        holder.qty.setText("Qty: " + item.getQuantity());

        // Delete button action
        holder.deleteBtn.setOnClickListener(v -> {
            db.deleteInventoryItem(item.getId());
            refreshCallback.run();
        });

        // On row click: open update dialog
        holder.itemView.setOnClickListener(v -> {
            showUpdateDialog(v.getContext(), item);
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    // Update popup
    private void showUpdateDialog(Context context, InventoryItem item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Update Item");

        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 30, 40, 10);

        EditText nameInput = new EditText(context);
        nameInput.setHint("Item Name");
        nameInput.setText(item.getName());
        layout.addView(nameInput);

        EditText qtyInput = new EditText(context);
        qtyInput.setHint("Quantity");
        qtyInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        qtyInput.setText(String.valueOf(item.getQuantity()));
        layout.addView(qtyInput);

        builder.setView(layout);

        builder.setPositiveButton("Update", (dialog, which) -> {
            String name = nameInput.getText().toString().trim();
            int qty = Integer.parseInt(qtyInput.getText().toString().trim());
            db.updateInventoryItem(item.getId(), name, qty);
            refreshCallback.run();
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    // ViewHolder
    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, qty;
        Button deleteBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.itemNameText);
            qty = itemView.findViewById(R.id.itemQtyText);
            deleteBtn = itemView.findViewById(R.id.deleteButton);
        }
    }
}
